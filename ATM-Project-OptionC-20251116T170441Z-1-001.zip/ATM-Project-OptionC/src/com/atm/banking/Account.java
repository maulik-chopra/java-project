package com.atm.banking;

import com.atm.transactions.Transaction;

public class Account {
    private String accountNumber;
    private String holderName;
    private String pin;
    private double balance;

    private Transaction[] miniStatement;
    private int stmtIndex;

    public Account(String accountNumber, String holderName, String pin,
                   double balance, int stmtCapacity) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.pin = pin;
        this.balance = balance;
        this.miniStatement = new Transaction[stmtCapacity];
        this.stmtIndex = 0;
    }

    public String getAccountNumber() { return accountNumber; }
    public String getHolderName() { return holderName; }

    public boolean validatePin(String attempt) {
        return this.pin.equals(attempt);
    }

    public synchronized void deposit(double amount) { this.balance += amount; }
    public synchronized void withdraw(double amount) { this.balance -= amount; }

    public double getBalance() { return this.balance; }

    public void addTransaction(Transaction tx) {
        if (stmtIndex >= miniStatement.length) {
            for (int i = 1; i < miniStatement.length; i++)
                miniStatement[i-1] = miniStatement[i];
            miniStatement[miniStatement.length - 1] = tx;
        } else {
            miniStatement[stmtIndex++] = tx;
        }
    }

    public Transaction[] getMiniStatement() {
        int filled = Math.min(stmtIndex, miniStatement.length);
        Transaction[] copy = new Transaction[filled];
        for (int i = 0; i < filled; i++) copy[i] = miniStatement[i];
        return copy;
    }

    public String toCSV() {
        return accountNumber + "," + holderName.replace(","," ") + "," + pin + "," + balance;
    }

    public static Account fromCSV(String line, int capacity) throws Exception {
        String[] p = line.split(",");
        if (p.length < 4) throw new Exception("Invalid CSV: " + line);
        return new Account(p[0].trim(), p[1].trim(), p[2].trim(), Double.parseDouble(p[3].trim()), capacity);
    }
}
